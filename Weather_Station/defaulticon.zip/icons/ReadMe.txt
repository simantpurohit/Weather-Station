--------------------------------------------------------------------------------
DefaultIcon ver 0.11
Available for download at
http://www.defaulticon.com
--------------------------------------------------------------------------------



--------------------------------------------------------------------------------
  INTERACTIVEMANIA
  Copyright (c) � 2010 Apostolos Paschalidis interactivemania
  All Rights Reserved.
  http://www.interactivemania.com

  NOTICE: interactivemania permits you to use, modify, and distribute this file
  in accordance with the terms of the license agreement mentioned in the section 
  "COPYRIGHT NOTICE" below.
--------------------------------------------------------------------------------



--------------------------------------------------------------------------------
Release History
===============
-- 58 Icons in total

-- 05 icons added 2010 Mar 24 ver 0.11
-- 53 icons added 2010 Mar 18 ver 0.10
--------------------------------------------------------------------------------



--------------------------------------------------------------------------------
Available Formats
=================
-- .eps
-- .png (16x16, 24x25, 32x32, 48x48, 64x64, 128x128, 256x256) black, white
-- .gif (16x16, 24x25, 32x32, 48x48, 64x64, 128x128, 256x256) black, white
--------------------------------------------------------------------------------



--------------------------------------------------------------------------------
COPYRIGHT NOTICE:
=================
Anyone downloading and/or using DefaultIcon agrees to the following license:

License
=======
The license under which DefaultIcon is released is licensed under a Creative 
Commons Attribution-No Derivative Works 3.0. More can be found
at http://creativecommons.org/licenses/by-nd/3.0/ .In short terms this means
This license allows for redistribution, commercial and non-commercial, as long 
as it is passed along unchanged and in whole, with credit to interactivemania
(with link http://www.interactivemania.com)
--------------------------------------------------------------------------------



--------------------------------------------------------------------------------
Contact us at:
http://www.defaulticon.com
info@defaulticon.com
--------------------------------------------------------------------------------



--------------------------------------------------------------------------------
Thessaloniki, Greece 18 Mar 2010
--------------------------------------------------------------------------------